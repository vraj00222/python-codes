# -*- coding: utf-8 -*-
"""
Created on Sun Feb  7 12:12:12 2021

@author: ASUS ROG
"""


import re
S = input("Input your password:- ")
x = True
while x:  
    if (len(S)<6 or len(S)>16):
        break
    elif not re.search("[a-z]",S):
        break
    elif not re.search("[0-9]",S):
        break
    elif not re.search("[A-Z]",S):
        break
    elif not re.search("[$#@]",S):
        break
    elif re.search("\s",S):
        break
    else:
        print("Valid Password")
        x=False
        break

if x:
    print("Not a Valid Password")





