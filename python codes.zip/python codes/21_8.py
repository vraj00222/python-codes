str = input("Input a string")
a=0
b=0
for i in str:
    if i.isdigit():
        a=a+1
    elif i.isalpha():
        b=b+1
    else:
        pass
print("Letters", b)
print("Digits", a)