# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 11:20:49 2021

@author: ASUS ROG
"""
count=0
for i in range(100,130):
    if i>1:
        for j in range (2,i):
            if(i%j)==0:
                count=count+1
                break
        else:
            print(i)