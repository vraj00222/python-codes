

a = input("input rows:")
b = input("input column:")
a = int (a)
b = int (b)
arr = [[0]*b]*a 
arr = [[0 for b in range(b)] for a in range(a)] 
for row in range(a):
    for col in range(b):
        arr[row][col]= row*col
print(arr)
