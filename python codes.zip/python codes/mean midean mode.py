#21_VRAJPATEL

import random
import pandas as pd
from collections import Counter

list1=[] 
n=int(input(print("how many time you want to roll the dice:- ")))
for i in range (n):
    list1.append(random.randint(1,6))
print(list1)


##FREQUENCY TABLE
DATA = pd.Series(list1)
print(DATA.value_counts())


##MEAN
x = len(list1) 
sumoflist = sum(list1) 
mean = sumoflist / x

print("Mean of list is: " + str(mean))
list1.sort()

##MEDIAN 

x = len(list1) 
list1.sort() 

if x % 2 == 0: 
	median1 = list1[x//2] 
	median2 = list1[x//2 - 1] 
	median = (median1 + median2)/2
else: 
	median = list1[x//2] 
print("Median of list is: " + str(median))
    
##MODE

x = len(list1) 
  
data = Counter(list1) 
get_mode = dict(data) 
mode = [k for k, v in get_mode.items() if v == max(list(data.values()))] 
  
if len(mode) == x: 
    get_mode = "No mode found"
else: 
    get_mode = "Mode of list is / are: " + ', '.join(map(str, mode)) 
      
print(get_mode) 




