# -*- coding: utf-8 -*-
"""
Created on Thu Feb 11 09:14:10 2021

@author: ASUS ROG
"""

n = input("enter number :-")
n = int(n)
for i in range (0,n+1):
    if (i%3==0 and i%5==0):
        print ("SPRITEMAAZA")
    elif (i%3==0):
        print ("SPRITE")
    elif (i%5==0):
        print ("MAAZA")
    
    #SPRITEMAAZA, SPRITE, MAAZA, SPRITE, SPRITE, MAAZA, SPRITE, SPRITEMAAZA