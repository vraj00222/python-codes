# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 09:37:40 2021

@author: ASUS ROG
"""

a = input()
b = input()
c = input()
d = input()
e = input()
f = input()
print (a,"\n",b,"\n",c,"\n",d,"\n",e,"\n",f)
