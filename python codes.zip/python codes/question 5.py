# -*- coding: utf-8 -*-
"""
Created on Sat Mar 27 10:32:06 2021

@author: ASUS ROG
"""
import re
a = input ("input password for checking of validation :- ")
b = True
while b :
    if (len(a)<6 or len(a)>16):
        break
    elif not re.search("[a-z]",a):
        break
    elif not re.search("[A-Z]",a):
        break
    elif not re.search("[0-9]",a):
        break
    elif not re.search("[$#@]",a):
        break
    elif re.search("\s",a):
        break 
    else :
        print ("Valid password ")
        b=False
        break
if b:
    print ("not a valid password ")