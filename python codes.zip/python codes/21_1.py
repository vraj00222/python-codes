# -*- coding: utf-8 -*-
"""
Created on Sat Jan 30 17:57:41 2021

@author: ASUS ROG
"""
a = '''
 Twinkle, twinkle, little star,",
 \t  How I wonder what you are!
 \t\t Up above the world so high
 \t\t Like a diamond in the sky.
Twinkle, twinkle, little star,
 \t  How I wonder what you are  '''
print (a)