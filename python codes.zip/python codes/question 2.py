# -*- coding: utf-8 -*-
"""
Created on Sat Mar 27 10:23:43 2021

@author: ASUS ROG
"""

a = input("enter sentence :- ")
res = len(a.split())
print ("number of words in string:- "+str(res))