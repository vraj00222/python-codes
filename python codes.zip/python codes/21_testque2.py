# -*- coding: utf-8 -*-
"""
Created on Thu Feb 11 09:29:47 2021

@author: ASUS ROG
"""

"""When the wind blows in cold weather, the air feels even colder than it actually is because the
movement of the air increases the rate of cooling for warm objects, like people. This effect is
known as wind chill. In 2001, Canada, the United Kingdom and the United States adopted the
following formula for computing the wind chill index. Within the formula Ta is the air temperature in
degrees Celsius and V is the wind speed in kilometers per hour. A similar formula with different
constant values can be used for temperatures in degrees Fahrenheit and wind speeds in miles per
hour.
WCI = 13.12 + 0.6215Ta -11.37V0.16 + 0.3965 Ta V0.16


Interestingly, do you know by importing math library package and using math.pow() returns the
value of x to the power of y. Write a program that begins by reading the air temperature and wind
speed from the user. Once these values have been read your program should display the wind chill
index (WCI) rounded to two places decimal.
"""
Ta = input(print ("enter the air temperature:- "))
Ta=int(Ta)
v = input(print("enter the speed of wind:- "))
v=int(v)
WCI = 13.12 +(0.6215*Ta)-(11.37*(v**0.16))+(0.3965(Ta*(v**0.16)))
print (WCI)




































