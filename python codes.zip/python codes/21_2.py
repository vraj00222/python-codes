a = input("please enter your name: ")
b = input("please enter your age: ")
b = int (b)
c = 100 - b
print ("\n your name is: ", a," \n your age is : ", b)
print ("after ",c," you will turn 100 years old ")