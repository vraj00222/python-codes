# -*- coding: utf-8 -*-
"""
Created on Sun Feb  7 12:42:28 2021

@author: ASUS ROG
"""

str = ""
str1 = ( "a", "b", "c","d" )
print (str.join(str1))