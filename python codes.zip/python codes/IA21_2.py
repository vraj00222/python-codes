# -*- coding: utf-8 -*-
"""
Created on Fri May 14 10:47:05 2021

@author: ASUS ROG
"""

string=input("enter string : ")
freq=dict()
print(freq)
for i in string:
    if (i=="1" or i=="2" or i=="0"):
         freq[i]=freq.get(i,0)+1
        
   
    
print(freq)






    
    
        
    