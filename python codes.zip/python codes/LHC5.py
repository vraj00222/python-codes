# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 10:38:54 2021

@author: ASUS ROG
"""
a=(print ("please enter your grnder:-"))
b=int(input(print("enter your birthday month in number:- ")))
c=int(input(print("enter your birthday year:- ")))
d=int(input(print("enter your birthdate:- ")))
if (c<=2002):
    if (b>=2):
        print("you are eligable ")
        
    
    