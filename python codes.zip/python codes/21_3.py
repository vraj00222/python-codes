a = input ("enter a number")
a = int (a)
b = (a)+(a*a)+(a*a*a)
print ("result is:",b)