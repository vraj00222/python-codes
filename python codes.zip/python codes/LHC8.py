# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 11:09:57 2021

@author: ASUS ROG
"""

a = int (input(print("enter temperature:- ")))
if (a<=0):
    print("it is freezing")
elif(a>0 and a<15):
    print(" it is cold")
elif(a>15 and a<25):
    print(" it is a nice day")
elif(a>=25):
    print(" it is hot!")