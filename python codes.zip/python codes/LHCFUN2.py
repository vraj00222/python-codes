# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 11:59:34 2021

@author: ASUS ROG
"""
def sumofnumber(num): 
      
    # Computing MAX 
    x = 0
    y = 1
      
    for i in range(1, num+1): 
        y *= i 
        x = x + (i/ y) 
          
    return x
      
n = int(input("enter a number :- "))  
print("Sum:- ", sumofnumber(n))