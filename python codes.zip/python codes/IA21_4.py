# -*- coding: utf-8 -*-
"""
Created on Fri May 14 10:11:01 2021

@author: ASUS ROG
"""
#21vrajpatel
n=input("enter the number : ")
y=int(n)
s=0
q=y
while (y!=0):
    x=y%10
    s+=x**(len(n))
    y=y//10
if (s==q):
    print("given number is narcissist number")
else :
    print ("given number is not narcissist number ")
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    