# -*- coding: utf-8 -*-
"""
Created on Thu Feb 11 08:24:15 2021

@author: ASUS ROG
"""
list1=[]
n = input(print ("enter length of array"))
n = int(n)
print ("enter numbers")
   
for i in range (n):    
    data = int (input())
    list1.append(data)
print (list1)
list2=list1.reverse()
print(list2)

#print(list3)  
#print(list1 + list1.reverse())   

