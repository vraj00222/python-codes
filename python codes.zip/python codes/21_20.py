a = [1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 3, 5, 7, 7, 7, 7, 7, 7, 8, 8]
count = {}
for i in a:
   if i in count:
      count[i] += 1
   else:
      count[i] = 1
for x, y in count.items():
   print(f"{x}: {y}")
   
   
   
   
   