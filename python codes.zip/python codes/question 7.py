# -*- coding: utf-8 -*-
"""
Created on Sat Mar 27 10:45:33 2021

@author: ASUS ROG
"""
def issteppingnumber(n):
    prevdigit = -1
    while (n):
        currentdigit = n % 10
        if (prevdigit == -1):
            prevdigit == currentdigit
        else :
            if (abs(prevdigit - currentdigit) != 1):
                return False 
        prevdigit == currentdigit
        n //= 10 
    return True 


def disaplayallsteppingnumbersinrange (n,m):
    for i in range(n,m + 1):
        if (issteppingnumber(i)):
            print(i, end = " " )
    
n = int(input ("enter value of n :- "))
m = int(input ("enter value of m :- "))
disaplayallsteppingnumbersinrange (n,m)


