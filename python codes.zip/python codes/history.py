
## ---(Fri Feb 19 16:14:45 2021)---
runfile('C:/Users/ASUS ROG/.spyder-py3/untitled0.py', wdir='C:/Users/ASUS ROG/.spyder-py3')
list1=[]
import random
n=int(input(print("how many time you want to roll the dice:- ")))
for i in range (n):
    list1.append(random.randint(1,6))
print(list1)
list1.sort()
runfile('C:/Users/ASUS ROG/.spyder-py3/untitled0.py', wdir='C:/Users/ASUS ROG/.spyder-py3')
runfile('C:/Users/ASUS ROG/.spyder-py3/untitled1.py', wdir='C:/Users/ASUS ROG/.spyder-py3')
runfile('C:/Users/ASUS ROG/.spyder-py3/mean midean mode.py', wdir='C:/Users/ASUS ROG/.spyder-py3')
list1=[]
import random
import pandas as pd
from collections import Counter 
n=int(input(print("how many time you want to roll the dice:- ")))
for i in range (n):
    list1.append(random.randint(1,6))
print(list1)
##MEAN
x = len(list1) 
sumoflist = sum(list1) 
mean = sumoflist / x

print("Mean of list is: " + str(mean))
list1.sort()

##FREQUENCY TABLE
DATA = pd.Series(list1)

#find frequencies of each value
DATA.value_counts()
list1=[]
import random
import pandas as pd
from collections import Counter 
n=int(input(print("how many time you want to roll the dice:- ")))
for i in range (n):
    list1.append(random.randint(1,6))
print(list1)
##MEAN
x = len(list1) 
sumoflist = sum(list1) 
mean = sumoflist / x

print("Mean of list is: " + str(mean))
list1.sort()

##FREQUENCY TABLE
DATA = pd.Series(list1)

#find frequencies of each value
DATA.value_counts()


##MEDIAN 

x = len(list1) 
list1.sort() 

if x % 2 == 0: 
	median1 = list1[x//2] 
	median2 = list1[x//2 - 1] 
	median = (median1 + median2)/2
else: 
	median = list1[x//2] 
print("Median of list is: " + str(median))

##MODE

x = len(list1) 

data = Counter(list1) 
get_mode = dict(data) 
mode = [k for k, v in get_mode.items() if v == max(list(data.values()))] 

if len(mode) == x: 
    get_mode = "No mode found"
else: 
    get_mode = "Mode of list is / are: " + ', '.join(map(str, mode)) 

print(get_mode)
runfile('C:/Users/ASUS ROG/.spyder-py3/mean midean mode.py', wdir='C:/Users/ASUS ROG/.spyder-py3')

## ---(Thu Feb 25 12:57:48 2021)---
runfile('C:/Users/ASUS ROG/.spyder-py3/untitled0.py', wdir='C:/Users/ASUS ROG/.spyder-py3')

## ---(Sat Mar 27 09:01:14 2021)---
runfile('C:/Users/ASUS ROG/.spyder-py3/LHCFUN1.py', wdir='C:/Users/ASUS ROG/.spyder-py3')
runfile('C:/Users/ASUS ROG/.spyder-py3/mergesort.py', wdir='C:/Users/ASUS ROG/.spyder-py3')
runfile('C:/Users/ASUS ROG/.spyder-py3/question 2.py', wdir='C:/Users/ASUS ROG/.spyder-py3')
runfile('C:/Users/ASUS ROG/.spyder-py3/question 5.py', wdir='C:/Users/ASUS ROG/.spyder-py3')
runfile('C:/Users/ASUS ROG/.spyder-py3/binarysearch.py', wdir='C:/Users/ASUS ROG/.spyder-py3')
runfile('C:/Users/ASUS ROG/.spyder-py3/question 4.py', wdir='C:/Users/ASUS ROG/.spyder-py3')
runfile('C:/Users/ASUS ROG/.spyder-py3/question 7.py', wdir='C:/Users/ASUS ROG/.spyder-py3')
runfile('C:/Users/ASUS ROG/.spyder-py3/question 3.py', wdir='C:/Users/ASUS ROG/.spyder-py3')

## ---(Thu May 13 22:22:02 2021)---
runfile('C:/Users/ASUS ROG/.spyder-py3/untitled0.py', wdir='C:/Users/ASUS ROG/.spyder-py3')

## ---(Fri May 14 10:10:47 2021)---
runfile('C:/Users/ASUS ROG/.spyder-py3/untitled0.py', wdir='C:/Users/ASUS ROG/.spyder-py3')
runfile('C:/Users/ASUS ROG/.spyder-py3/untitled1.py', wdir='C:/Users/ASUS ROG/.spyder-py3')
runfile('C:/Users/ASUS ROG/.spyder-py3/untitled2.py', wdir='C:/Users/ASUS ROG/.spyder-py3')
string=input("enter string : ")
freq=dict()
print(freq)
for i in string:
    if (i=="1" or i=="2" or i=="0"):
         freq[i]=freq.get(i,0)+1



print(freq)
runfile('C:/Users/ASUS ROG/.spyder-py3/untitled4.py', wdir='C:/Users/ASUS ROG/.spyder-py3')
d=256

def search(p,s,q):
    M = len(p)
    N = len(s)
    i=0
    j=0
    y=0
    t=0
    h=1
    
    for i in range(M-1):
        h = (h*d)%q
    
    
    for i in range(M):
        y=(d*y +ord(p[i]))%q
        t=(d*t + ord(s[i]))%q
    for i in range (N-M + 1):
        
        if y ==t :
            for j in range (M):
                if s[i+j] != p[j]:
                    break
            j+= 1
            
            if j == M:
                print ("pattern found at index "+str(i))
        if t<0:
            t=t+q


s="This is a python test "
p= "python"

q=101
search(p,s,q)
runfile('C:/Users/ASUS ROG/.spyder-py3/untitled4.py', wdir='C:/Users/ASUS ROG/.spyder-py3')
runfile('C:/Users/ASUS ROG/.spyder-py3/untitled3.py', wdir='C:/Users/ASUS ROG/.spyder-py3')