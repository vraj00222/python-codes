# -*- coding: utf-8 -*-
"""
Created on Sat Mar 27 10:26:50 2021

@author: ASUS ROG
"""
def activityselection(s,f):
    n=len(s)
    index=[i for i in range (1,len(s)+1)]
    for i in range (n):
        for j in range (n-1-i):
            if (f[j]>f[j+1]):
                f[j],f[j+1]=f[j+1],f[j]
                s[j],s[j+1]=s[j+1],s[j]
                index[j],index[j+1]=index[j+1],index[j]
    activity=[]
    activity=[index[0]]
    f_time=f[0]
    
    for k in range (0,len(index)):
        print(s[k] >= f_time )
        if (s[k]>=f_time):
            activity +=str(index[k])
            f_time=f[k]
            
    return activity
    







s=[1,12,5,7,9,0]
f=[3,13,7,8,11,12]
activity = activityselection(s,f)
print (activity)

