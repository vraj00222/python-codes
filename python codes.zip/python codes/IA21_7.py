# -*- coding: utf-8 -*-
"""
Created on Fri May 14 11:04:52 2021

@author: ASUS ROG
"""
#21vrajpatel
d=256

def search(p,s,q):
    M = len(p)
    N = len(s)
    i=0
    j=0
    y=0
    t=0
    h=1
    
    for i in range(M-1):
        h = (h*d)%q
            

    for i in range(M):
        y=(d*y +ord(p[i]))%q
        t=(d*t + ord(s[i]))%q
    for i in range (N-M + 1):
        
        if y ==t :
            for j in range (M):
                if s[i+j] != p[j]:
                    break
            j+= 1
            
            if j == M:
                print ("pattern found at index "+str(i))
        
        if i < N-M:
            t= (d*(t-ord(s[i])*h) + ord(s[i+M]))%q
            
            if t<0:
                t=t+q

s="This is a python test "
p= "python"

q=101
search(p,s,q)

































