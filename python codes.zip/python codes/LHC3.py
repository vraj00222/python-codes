# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 09:53:35 2021

@author: ASUS ROG
"""

a = input ("enter string")
alphabet=""
number=""
specialcharacter=""
for i in range(len(a)):
    if(a[i].isdigit()):
        number=number+a[i]
    elif(a[i].isalpha()):
        alphabet=alphabet+a[i]
    else:
        specialcharacter=specialcharacter+a[i]
print(alphabet)
print(number)
print(specialcharacter)



x=input(print ("enter a number:-"))
y=input(print ("enter a number:-"))
x=float(x)
y=float(y)
if (type(x)==float and type(y)==float ):
    print (x+y)