# -*- coding: utf-8 -*-
"""
Created on Sun Feb  7 12:20:27 2021

@author: ASUS ROG
"""

a = input("value of one side of shape:")
b = input("value of second side of shape:")
c = input("value of third side of shape:")

a = int(a)
b = int(b)
c = int(c)

if a==b and b==c and a==c:
    print ("This is a equilateral traingle")
elif a!=b and b!=c and a!=c:
    print ("This is a scalene traingle")
elif a==b or b==c or a==c:
    print ("This is a isosceles triangle")

#a,b b,c
#b,c a,c









