# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 11:44:05 2021

@author: ASUS ROG
"""
def average(n1, n2, n3): 
	total = n1 + n2 + n3 
	Avg = total/3 
	return Avg 
 
    
a=int(input(print ("enter a number:- ")))
b=int(input(print ("enter a number:- ")))
c=int(input(print ("enter a number:- ")))

print(average(a,b,c)) 