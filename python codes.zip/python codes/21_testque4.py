# -*- coding: utf-8 -*-
"""
Created on Thu Feb 11 09:46:47 2021

@author: ASUS ROG
"""

str1="aabbcccddddddd"
print("a","=",str1.count("a"))


