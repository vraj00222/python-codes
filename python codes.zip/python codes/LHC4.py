# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 10:13:42 2021

@author: ASUS ROG
"""

a=int(input("enter integer:- "))
b=int(input("enter integer:- "))
c=float(input("enter float:- "))
d=float(input("enter float:- "))
e=int(input("enter double:- "))
f=int(input("enter double:- "))
g=input("enter character:- ")
h=input("enter character:- ")
print ("addition of g+h",g+h)
print ("sub of c-d",c-d)
print ("mul of exf",e*f)
print ("div of c/e",c/e)
print ("modulous of a%b",a%b)
print ("bitwise operator &",a&b)
print ("bitwise operator |",c|d)
print ("bitwise operator ~",~f)
print ("bitwise operator ^",e&f)
print ("bitwise operator <<",(e<<f))
print ("bitwise operator >>",(e>>f))