# -*- coding: utf-8 -*-
"""
Created on Fri Feb 19 08:37:12 2021

@author: ASUS ROG
"""

n=int(input(print("enter length of list:- ")))
l = [int(input()) for i in range(n)]
for i in range (n):
    k = l[i]
    j = i - 1
    while j>=0 and k<l[j]:
        l[j+1]=l[j]
        j=j-1
    else:
        l[j+1]=k
print('sorted list: ',l)