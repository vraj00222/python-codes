# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 10:54:32 2021

@author: ASUS ROG
"""

a = int(input("enter number between 1 to 100;- "))

if(a%2==0):
    print("EVEN NUMBER")
else:
    print("ODD NUMBER")

if (a%3==0 or a%5==0 or a%7==0 or a%9==0 or a%11==0):
    print("ALMOST PRIME")