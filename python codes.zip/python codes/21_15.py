# -*- coding: utf-8 -*-
"""
Created on Sun Feb  7 12:34:01 2021

@author: ASUS ROG
"""

import re
S = input("Input your alphabet:- ")
if re.search("[a,e,i,o,u,A,E,I,O,U]",S):
    print ("it is a vowel ")
else :
    print ("it is not vowel")


