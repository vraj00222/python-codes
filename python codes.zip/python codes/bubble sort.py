# -*- coding: utf-8 -*-
"""
Created on Fri Feb 19 08:29:59 2021

@author: ASUS ROG
"""
n=int(input(print("enter length of list:- ")))
l = [int(input()) for i in range(n)]
for i in range (n):
    for j in range (n-i-1):
        if(l[j]>l[j+1]):
            l[j],l[j+1]=l[j+1],l[j]
print('sorted list: ',l)