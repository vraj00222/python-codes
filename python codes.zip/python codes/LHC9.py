# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 11:25:57 2021

@author: ASUS ROG
"""

for i in range (1,101):
    if (i%2==0 and i not in range (20,30) and  i!=58 and i!=78 and i!=96):
         print(i)
        
   