# -*- coding: utf-8 -*-
"""
Created on Sun Feb  7 12:48:46 2021

@author: ASUS ROG
"""

list1 = [1, 2, 3, 4]
list2=[1, 2]
a = list(set(list1) - set(list2))
b = list(set(list2) - set(list1))
c = a + b
print (c)



