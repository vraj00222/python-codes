import random
n = random.randint(1,9)
print(n)
a= input(print ("guess a number :- "))
a = int(a)
if a<n:
    print ("The number you guessed is lower ")
elif a>n:
    print ("The number you guessed is greater ")
else :
    print ("you guessed the same number ")
    


