# -*- coding: utf-8 -*-
"""
Created on Fri May 14 10:32:36 2021

@author: ASUS ROG
"""

import collections
def bfs(graph,root):
    vd,queue= set(),collections.deque([root])
    vd.add(root)
    
    while queue:
        vr=queue.popleft()
        print(str(vr) + "",end = "")
        
        for n in graph[vr]:
            if n not in vd:
                vd.add(n)
                queue.append(n)
        

graph={0:[1],1:[0,2,3],2:[1,3,4],3:[1,2],4:[2,6],5:[6],6:[4,5]}
print("breadth first traversal: ")
bfs(graph,0)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    