# -*- coding: utf-8 -*-
"""
Created on Mon Feb 15 09:43:17 2021

@author: ASUS ROG
"""

a = input ("enter a string :- ")
b = input ("enter a string :- ")
c = int(a)
d = int(b)
if (type(c)==int and type(d)==int ):
    print (c+d)