a = input ("enter a how many numbers you want in this series : ")
a = int(a)
first = 0 
second = 1
while first <= a :
    print (first)
    temp = first 
    first = second 
    second = temp + first 
    