
def binarysearch(L,key):
    low = 0
    high = len(L)-1
    found = False
    while low<=high and not found:
        mid = (low+high)//2
        if key == L[mid]:
            found=True 
        elif key>L[mid]:
            low = mid + 1
        else:
            high = mid -1
    if found == True:
        print("key is found")
    else:
        
        print("key is not found ")
    



n = int(input("enter the list length:- "))
L=[int(input())for i in range(n)]
L.sort()
key =  int(input("enter the key :- "))
binarysearch(L,key)


