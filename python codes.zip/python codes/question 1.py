# -*- coding: utf-8 -*-
"""
Created on Sat Mar 27 09:01:22 2021

@author: ASUS ROG
"""
"""Question 1. [2]
Consider the following program
n = int ( input (" Enter a positive integer : "))
total = n*n + n / 2
print (" The total of the first n positive integers is", total)
It is supposed to calculate the total of the first n positive integers, which can be computed with the
standard formula as sum of (squares of n numbers and the n numbers) which is then divided by 2.
However, the program does not produce correct results. No error messages are displayed when
the program runs. What change should be made to this program so that it will display the correct
total? Write as the comment in the code with the modified program.
"""

n = int ( input (" Enter a positive integer : "))
total = (n*n + n) / 2
print (" The total of the first n positive integers is", total)