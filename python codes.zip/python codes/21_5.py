a = input("value of one angle of shape:")
b = input("value of second angle of shape:")
c = input("value of third angle of shape:")

a = int(a)
b = int(b)
c = int(c)

x = a+b+c

if x==180 :
    print ("This is a traingle shape ")
else :
    print ("This is not a traingle ")

