a = [1,2,-8,0] 
  
a.sort() 
  

print("Smallest element is:", *a[:1])
print("largest element is:", *a[3:4])

