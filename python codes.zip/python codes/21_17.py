# -*- coding: utf-8 -*-
"""
Created on Sun Feb  7 13:01:02 2021

@author: ASUS ROG
"""

color1 = "Red", "Green", "Orange", "White"
color2 = "Black", "Green", "White", "Pink"
print(set(color1) & set(color2))


